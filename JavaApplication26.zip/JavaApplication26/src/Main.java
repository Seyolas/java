
import javax.swing.JFrame;

public class Main extends JFrame {
	
	public Main() {
		super("Mayin Tarlasi");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		add(new OyunAlani());
		pack();
		setVisible(true);
	}
	
	public static void main(String[] args) {
		new Main();
	}
}
