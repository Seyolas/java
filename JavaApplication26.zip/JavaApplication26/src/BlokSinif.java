
import java.awt.Dimension;
import java.awt.Insets;
import javax.swing.JButton;

public class BlokSinif extends JButton{

    private int satir, sutun;
    private int turu;

    public BlokSinif(int satir, int sutun) {
        setPreferredSize(new Dimension(24,24));
        setMargin(new Insets(1,1,1,1));
        this.satir = satir;
        this.sutun = sutun;
        this.turu = 0;
    }

    public void setMayin() { turu = 9; }

    public boolean mayinmi() { return turu == 9 ? true : false; }

    public boolean MayinKaldimi() { return turu == 0 ? true : false; }

    public void mayinekle() { turu++; }

    public int getSatir() { return satir; }
    public int getSutun() { return sutun; }

    public int getTur() { return turu; }
}
