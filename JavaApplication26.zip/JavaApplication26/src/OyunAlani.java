
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class OyunAlani extends JPanel implements ActionListener{

    private int mayinSayisi;
    private BlokSinif[][] bloklar;
    private Dimension gridBoyut;
    private int kalanBloklar;
    public OyunAlani() {
        gridBoyut = new Dimension(20,20);
        setLayout(new GridLayout(gridBoyut.height,gridBoyut.width));
        mayinSayisi = 20;
        kalanBloklar = gridBoyut.width * gridBoyut.height;
        bloklar = new BlokSinif[gridBoyut.height][gridBoyut.width];
        for (int i = 0; i < gridBoyut.width; i++) {
            for (int j = 0; j < gridBoyut.height; j++) {
                bloklar[i][j] = new BlokSinif(i,j);
                bloklar[i][j].addActionListener(this);
                add(bloklar[i][j]);
            }
        }
        mayinEkle();
        setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            buttonEkle((BlokSinif)(e.getSource()));
        } catch(Exception exc) {
            System.err.println(
                    exc.getMessage()+"Sadece bloklara tiklanabilir."
            );
        }
    }
    private void mayinlariGoster() {
        for (BlokSinif[] satirBlokSinifs : bloklar) {
            for (BlokSinif blok : satirBlokSinifs) {
                if (blok.mayinmi())
                    blok.setText("X");
            }
        }
    }
    private void buttonEkle(BlokSinif blok) {
        blok.setEnabled(false);
        if (blok.MayinKaldimi())
            komsulariAc(blok);
        else if (blok.mayinmi())
            kaybettiniz();
        else
            blok.setText(Integer.toString(blok.getTur()));
        kalanBloklar--;
        if (kalanBloklar == mayinSayisi)
            kaybettiniz();
    }
    private void mayinEkle() {
        int mayinAdeti = 0;
        Random random = new Random();

        while (mayinAdeti != mayinSayisi) {
            int i = random.nextInt(bloklar.length);
            int j = random.nextInt(bloklar[0].length);
            if (!bloklar[i][j].mayinmi()) {
                bloklar[i][j].setMayin();
                for (int satir = i-1;satir <= i+1; satir++) {
                    for (int sutun = j-1; sutun <= j+1; sutun++) {
                        if (satir == i && sutun == j)
                            continue;
                        if (satir < 0 || satir > gridBoyut.height-1 ||
                                sutun < 0 || sutun > gridBoyut.width-1
                        )
                            continue;
                        if(!bloklar[satir][sutun].mayinmi())
                            bloklar[satir][sutun].mayinekle();
                    }
                }
                mayinAdeti++;
            }
        }
    }
    private void kaybettiniz() {
        if (kalanBloklar != mayinSayisi) {
            mayinlariGoster();
            JOptionPane.showMessageDialog(this,"Malesef Kaybettiniz");
        } else {
            JOptionPane.showMessageDialog(this,"Tebrikler! Kazandiniz!");
        }
        System.exit(0);
    }
    public void komsulariAc(BlokSinif blok) {
        int satir = blok.getSatir();
        int sutun = blok.getSutun();

        for (int i = satir-1;i <= satir+1; i++) {
            for (int j = sutun-1; j <= sutun+1; j++) {
                if (i == satir && j == sutun)
                    continue;
                if (i < 0 || i > gridBoyut.height-1 || j < 0 || j > gridBoyut.width-1)
                    continue;
                if(bloklar[i][j].isEnabled())
                    buttonEkle(bloklar[i][j]);
            }
        }
    }
}
