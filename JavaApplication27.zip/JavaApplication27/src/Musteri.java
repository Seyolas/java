import java.util.ArrayList;

public class Musteri {
public static ArrayList<Musteri> Musteriler = new ArrayList<Musteri>();
public static int uniqueid=0;
private int Musteriid;
private String ad;
private String soyad;
private String sifre;



public Musteri(String ad, String soyad, String sifre) {
	super();
	this.ad = ad;
	this.soyad = soyad;
	this.sifre = sifre;
	this.Musteriid=uniqueid;
	Musteriler.add(this);
	uniqueid++;
}
public Musteri(int id,String ad, String soyad, String sifre) {
	super();
	this.ad = ad;
	this.soyad = soyad;
	this.sifre = sifre;
	this.Musteriid=id;
	Musteriler.add(this);
}
public static Musteri musteriBul(int id) {
	for(Musteri m:Musteriler) {
		if(m.getMusteriid()==id) {
			return m;
		}
	}
	return null;
}
public String toString() {
	return "Musteri ID: "+this.getMusteriid()+" Adi: "+this.getAd()+" Soyadi: "+this.getSoyad()+" Sifre: "+this.getSifre();
}
public int getMusteriid() {
	return Musteriid;
}
public void setMusteriid(int musteriid) {
	Musteriid = musteriid;
}
public String getAd() {
	return ad;
}
public void setAd(String ad) {
	this.ad = ad;
}
public String getSoyad() {
	return soyad;
}
public void setSoyad(String soyad) {
	this.soyad = soyad;
}
public String getSifre() {
	return sifre;
}
public void setSifre(String sifre) {
	this.sifre = sifre;
}
}
