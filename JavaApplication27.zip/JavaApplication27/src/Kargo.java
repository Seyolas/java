import java.util.ArrayList;

public class Kargo {
public static ArrayList<Kargo> Kargolar = new ArrayList<Kargo>();
public static int uniqueid=0;
private int Kargoid;
private int Gonderilenid;
private int Gonderenid;
private String gonderilenAdres;
@Override
public String toString() {
	return "Kargo Bilgisi: Kargo Id=" + Kargoid + ", Gonderilen Kisi Id=" + Gonderilenid + ", Gonderen Kisi Id=" + Gonderenid
			+ ", Gonderilen Adres=" + gonderilenAdres + ", Gonderenin Adresi=" + gonderenAdres + ", Kargo Ucreti="
			+ kargoUcreti + "TL, Uzunluk=" + uzunluk + "CM, Yukseklik=" + yukseklik + "CM, Genislik="
			+ genislik + "CM, Mesafe=" + mesafe+"KM" +", Durum=" + durum ;
}
private String gonderenAdres;
private double kargoUcreti;
private int uzunluk;
private String durum;

public Kargo(int gonderilenid, int gonderenid, String gonderilenAdres,
		String gonderenAdres, int uzunluk, int yukseklik,
		int genislik, int mesafe,String durum) {
	super();
	Gonderilenid = gonderilenid;
	Gonderenid = gonderenid;
	this.gonderilenAdres = gonderilenAdres;
	this.gonderenAdres = gonderenAdres;
	this.uzunluk = uzunluk;
	this.yukseklik = yukseklik;
	this.genislik = genislik;
	this.mesafe = mesafe;
	this.kargoUcreti = ((yukseklik*genislik*uzunluk)/1000)+(mesafe/10);
	this.Kargoid=uniqueid;
	this.durum=durum;
	uniqueid++;
	Kargolar.add(this);
}
public Kargo(int kargoid,int gonderenid, int gonderilenid, String gonderenAdres,
		String gonderilenAdres,double kargoucreti,String durum) {
	super();
	Gonderilenid = gonderilenid;
	Gonderenid = gonderenid;
	this.gonderilenAdres = gonderilenAdres;
	this.gonderenAdres = gonderenAdres;
	this.uzunluk = 0;
	this.yukseklik = 0;
	this.genislik = 0;
	this.mesafe = 0;
	this.kargoUcreti = kargoucreti;
	this.Kargoid=kargoid;
	this.durum=durum;
	Kargolar.add(this);
}
public static Kargo kargoBul(int Kargoid) {
	for(Kargo kargo:Kargolar) {
		if(kargo.Kargoid==Kargoid) {
			return kargo;
		}
	}
	return null;
}
private int yukseklik;
private int genislik;




public int getKargoid() {
	return Kargoid;
}
public void setKargoid(int kargoid) {
	Kargoid = kargoid;
}
public int getGonderilenid() {
	return Gonderilenid;
}
public void setGonderilenid(int gonderilenid) {
	Gonderilenid = gonderilenid;
}
public String getDurum() {
	return durum;
}
public void setDurum(String durum) {
	this.durum = durum;
}
public int getGonderenid() {
	return Gonderenid;
}
public void setGonderenid(int gonderenid) {
	Gonderenid = gonderenid;
}
public String getGonderilenAdres() {
	return gonderilenAdres;
}
public void setGonderilenAdres(String gonderilenAdres) {
	this.gonderilenAdres = gonderilenAdres;
}
public String getGonderenAdres() {
	return gonderenAdres;
}
public void setGonderenAdres(String gonderenAdres) {
	this.gonderenAdres = gonderenAdres;
}
public double getKargoUcreti() {
	return kargoUcreti;
}
public void setKargoUcreti(double kargoUcreti) {
	this.kargoUcreti = kargoUcreti;
}
public int getUzunluk() {
	return uzunluk;
}
public void setUzunluk(int uzunluk) {
	this.uzunluk = uzunluk;
}
public int getYukseklik() {
	return yukseklik;
}
public void setYukseklik(int yukseklik) {
	this.yukseklik = yukseklik;
}
public int getGenislik() {
	return genislik;
}
public void setGenislik(int genislik) {
	this.genislik = genislik;
}
public int getMesafe() {
	return mesafe;
}
public void setMesafe(int mesafe) {
	this.mesafe = mesafe;
}
int mesafe;

}
