import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.table.TableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JList;
import javax.swing.SwingConstants;
import javax.swing.ListSelectionModel;

public class YoneticiEkrani {

	JFrame frmYoneticiIslemleri;
	private JTextField txtGonderilenid;
	private JTextField txtGonderenid;
	private JTextField txtGonderilenadres;
	private JTextField txtGonderenadres;
	private JTextField txtMesafe;
	private JTextField txtUzunluk;
	private JTextField txtYukseklik;
	private JTextField txtGenislik;
	private JLabel lblkargoUcreti;
	private JTextField txtYeniAdres;
	private JTextField txtDurum;
	DefaultListModel<String> KargoModel = new DefaultListModel<String>();
	DefaultListModel<String> MusteriModel = new DefaultListModel<String>();
	JList kargolist = new JList(KargoModel);
	JList musterilist = new JList(MusteriModel);
	private JTextField txtMusteriAd;
	private JTextField txtMusteriSoyad;
	private JTextField txtMusteriSifre;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				YoneticiEkrani window = new YoneticiEkrani();
				window.frmYoneticiIslemleri.setVisible(true);
			}
		});
	}

	
	public YoneticiEkrani() {
		initialize();
		kargoListele();
	}
	void kargoListele() {
		for(Kargo kargo:Kargo.Kargolar) {
				KargoModel.addElement(String.valueOf(kargo.getKargoid()));
		}
		for(Musteri musteri:Musteri.Musteriler) {
			MusteriModel.addElement(String.valueOf(musteri.getMusteriid()));
	}
	}
	
	private void initialize() {
		frmYoneticiIslemleri = new JFrame();
		frmYoneticiIslemleri.setTitle("Yonetici Islemleri");
		frmYoneticiIslemleri.setBounds(100, 100, 519, 467);
		frmYoneticiIslemleri.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		frmYoneticiIslemleri.getContentPane().setLayout(null);

		
		JButton btnUcretHesapla = new JButton("Ucret Hesapla");
		btnUcretHesapla.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!txtMesafe.getText().equals("")&&!txtUzunluk.getText().equals("")&&!txtYukseklik.getText().equals("")
							&&!txtGenislik.getText().equals(""))
				{
				int Mesafe = Integer.parseInt(txtMesafe.getText());
				int Uzunluk = Integer.parseInt(txtUzunluk.getText());
				int Yukseklik = Integer.parseInt(txtYukseklik.getText());
				int Genislik = Integer.parseInt(txtYukseklik.getText());
				double Ucret = ((Uzunluk*Yukseklik*Genislik)/1000)+(Mesafe/10);
				lblkargoUcreti.setText(String.valueOf(Ucret)+"TL");
				}
				else {
					JOptionPane.showMessageDialog(null, "Gerekli Alanlari Doldurunuz!");
				}
			}
		});
		btnUcretHesapla.setFont(new Font("Arial", Font.PLAIN, 10));
		btnUcretHesapla.setBounds(391, 87, 102, 23);
		frmYoneticiIslemleri.getContentPane().add(btnUcretHesapla);
		
		txtGonderilenid = new JTextField();
		txtGonderilenid.setFont(new Font("Arial", Font.PLAIN, 10));
		txtGonderilenid.setBounds(10, 34, 86, 20);
		frmYoneticiIslemleri.getContentPane().add(txtGonderilenid);
		txtGonderilenid.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Gonderilen Kisi ID");
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 10));
		lblNewLabel.setBounds(10, 11, 89, 14);
		frmYoneticiIslemleri.getContentPane().add(lblNewLabel);
		
		txtGonderenid = new JTextField();
		txtGonderenid.setFont(new Font("Arial", Font.PLAIN, 10));
		txtGonderenid.setColumns(10);
		txtGonderenid.setBounds(106, 34, 86, 20);
		frmYoneticiIslemleri.getContentPane().add(txtGonderenid);
		
		JLabel lblGonderenKisiId = new JLabel("Gonderen Kisi ID");
		lblGonderenKisiId.setFont(new Font("Arial", Font.PLAIN, 10));
		lblGonderenKisiId.setBounds(106, 11, 86, 14);
		frmYoneticiIslemleri.getContentPane().add(lblGonderenKisiId);
		
		txtGonderilenadres = new JTextField();
		txtGonderilenadres.setFont(new Font("Arial", Font.PLAIN, 10));
		txtGonderilenadres.setColumns(10);
		txtGonderilenadres.setBounds(202, 34, 86, 20);
		frmYoneticiIslemleri.getContentPane().add(txtGonderilenadres);
		
		JLabel lblGonderilenAdres = new JLabel("Gonderilen Adres");
		lblGonderilenAdres.setFont(new Font("Arial", Font.PLAIN, 10));
		lblGonderilenAdres.setBounds(202, 11, 86, 14);
		frmYoneticiIslemleri.getContentPane().add(lblGonderilenAdres);
		
		txtGonderenadres = new JTextField();
		txtGonderenadres.setFont(new Font("Arial", Font.PLAIN, 10));
		txtGonderenadres.setColumns(10);
		txtGonderenadres.setBounds(298, 34, 99, 20);
		frmYoneticiIslemleri.getContentPane().add(txtGonderenadres);
		
		JLabel lblGonderenAdres = new JLabel("Gonderen Adres");
		lblGonderenAdres.setFont(new Font("Arial", Font.PLAIN, 10));
		lblGonderenAdres.setBounds(298, 11, 86, 14);
		frmYoneticiIslemleri.getContentPane().add(lblGonderenAdres);
		
		txtMesafe = new JTextField();
		txtMesafe.setFont(new Font("Arial", Font.PLAIN, 10));
		txtMesafe.setColumns(10);
		txtMesafe.setBounds(10, 88, 86, 20);
		frmYoneticiIslemleri.getContentPane().add(txtMesafe);
		
		JLabel lblMesafekm = new JLabel("Mesafe (KM)");
		lblMesafekm.setFont(new Font("Arial", Font.PLAIN, 10));
		lblMesafekm.setBounds(10, 65, 89, 14);
		frmYoneticiIslemleri.getContentPane().add(lblMesafekm);
		
		txtUzunluk = new JTextField();
		txtUzunluk.setFont(new Font("Arial", Font.PLAIN, 10));
		txtUzunluk.setColumns(10);
		txtUzunluk.setBounds(106, 88, 86, 20);
		frmYoneticiIslemleri.getContentPane().add(txtUzunluk);
		
		JLabel lblPaketUzunlugu = new JLabel("Uzunluk (CM)");
		lblPaketUzunlugu.setFont(new Font("Arial", Font.PLAIN, 10));
		lblPaketUzunlugu.setBounds(106, 65, 86, 14);
		frmYoneticiIslemleri.getContentPane().add(lblPaketUzunlugu);
		
		txtYukseklik = new JTextField();
		txtYukseklik.setFont(new Font("Arial", Font.PLAIN, 10));
		txtYukseklik.setColumns(10);
		txtYukseklik.setBounds(202, 88, 86, 20);
		frmYoneticiIslemleri.getContentPane().add(txtYukseklik);
		
		JLabel lblYuksekligi = new JLabel("Yuksekligi (CM)");
		lblYuksekligi.setFont(new Font("Arial", Font.PLAIN, 10));
		lblYuksekligi.setBounds(202, 65, 86, 14);
		frmYoneticiIslemleri.getContentPane().add(lblYuksekligi);
		
		txtGenislik = new JTextField();
		txtGenislik.setFont(new Font("Arial", Font.PLAIN, 10));
		txtGenislik.setColumns(10);
		txtGenislik.setBounds(298, 88, 86, 20);
		frmYoneticiIslemleri.getContentPane().add(txtGenislik);
		
		JLabel lblGenisligi = new JLabel("Genisligi (CM)");
		lblGenisligi.setFont(new Font("Arial", Font.PLAIN, 10));
		lblGenisligi.setBounds(298, 65, 83, 14);
		frmYoneticiIslemleri.getContentPane().add(lblGenisligi);
		
	 lblkargoUcreti = new JLabel("Kargo Ucreti...");
		lblkargoUcreti.setFont(new Font("Arial", Font.PLAIN, 10));
		lblkargoUcreti.setBounds(401, 36, 92, 14);
		frmYoneticiIslemleri.getContentPane().add(lblkargoUcreti);
		
		JButton btnKargoEkle = new JButton("Kargo Ekle");
		btnKargoEkle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(!txtGonderilenid.getText().equals("")&&!txtGonderenid.getText().equals("")
					&&!txtMesafe.getText().equals("")&&!txtUzunluk.getText().equals("")&&!txtYukseklik.getText().equals("")
					&&!txtGonderenadres.getText().equals("")&&!txtGonderilenadres.getText().equals("")&&!txtGenislik.getText().equals("")) {
					
					if((Musteri.musteriBul(Integer.parseInt(txtGonderilenid.getText()))!=null)&&(Musteri.musteriBul(Integer.parseInt(txtGonderenid.getText()))!=null)){
						int Gonderilenid = Integer.parseInt(txtGonderilenid.getText());
						int Gonderenid = Integer.parseInt(txtGonderenid.getText());
						String gonderenadres = txtGonderenadres.getText();
						String gonderilenadres = txtGonderilenadres.getText();
						int Mesafe = Integer.parseInt(txtMesafe.getText());
						int Uzunluk = Integer.parseInt(txtUzunluk.getText());
						int Yukseklik = Integer.parseInt(txtYukseklik.getText());
						int Genislik = Integer.parseInt(txtYukseklik.getText());
						Kargo yeni = new Kargo(Gonderilenid,Gonderenid,gonderilenadres,gonderenadres,Uzunluk,Yukseklik,Genislik,Mesafe,"Subede");
						KargoModel.addElement(String.valueOf(yeni.getKargoid()));
						JOptionPane.showMessageDialog(null, "Kargo Kaydedildi.");
					}
					else {
						JOptionPane.showMessageDialog(null, "Bu ID'lere kayitli musteri bulunamadi.");
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "Tum Bos Alanlari Doldurun!");
				}
			}
		});
		btnKargoEkle.setFont(new Font("Arial", Font.BOLD, 13));
		btnKargoEkle.setBounds(106, 121, 377, 31);
		frmYoneticiIslemleri.getContentPane().add(btnKargoEkle);
		
		JButton btnKargoGuncelle = new JButton("Kargo Guncelle");
		btnKargoGuncelle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(kargolist.getSelectedIndex()>=0) {
					Kargo guncelle = Kargo.kargoBul(Integer.parseInt(String.valueOf(kargolist.getSelectedValue())));
					if(guncelle!=null) {
						if(!txtYeniAdres.getText().isEmpty()) {
							guncelle.setGonderilenAdres(txtYeniAdres.getText());
						}
						if(!txtDurum.getText().isEmpty()) {
							guncelle.setDurum(txtDurum.getText());
						}
						JOptionPane.showMessageDialog(null, "Girilen Veriler Guncellendi!");
						
					}
					else {
						JOptionPane.showMessageDialog(null, "Bu ID ile eslesen bir kargo bulunamadi, silmis olabilirsiniz.");
					}
				}
			}
		});
		btnKargoGuncelle.setFont(new Font("Arial", Font.BOLD, 13));
		btnKargoGuncelle.setBounds(212, 177, 281, 31);
		frmYoneticiIslemleri.getContentPane().add(btnKargoGuncelle);
		
		JButton btnKargoSil = new JButton("Kargo Sil");
		btnKargoSil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(kargolist.getSelectedIndex()>=0) {
					Kargo sil =  Kargo.kargoBul(Integer.parseInt(String.valueOf(kargolist.getSelectedValue())));
					if(sil!=null) {
						Kargo.Kargolar.remove(sil);
						JOptionPane.showMessageDialog(null, "Kargo Sistemden Silindi.");
					}
					else {
						JOptionPane.showMessageDialog(null, "Boyle Bir Kargo Bulunamadi, silmis olabilirsiniz.");
					}
				}
			}
		});
		btnKargoSil.setFont(new Font("Arial", Font.BOLD, 13));
		btnKargoSil.setBounds(345, 215, 148, 31);
		frmYoneticiIslemleri.getContentPane().add(btnKargoSil);
		
		txtYeniAdres = new JTextField();
		txtYeniAdres.setFont(new Font("Arial", Font.PLAIN, 10));
		txtYeniAdres.setColumns(10);
		txtYeniAdres.setBounds(106, 184, 86, 20);
		frmYoneticiIslemleri.getContentPane().add(txtYeniAdres);
		
		JLabel lblKargoId_1_1 = new JLabel("Gonderilen Adres");
		lblKargoId_1_1.setFont(new Font("Arial", Font.PLAIN, 10));
		lblKargoId_1_1.setBounds(106, 161, 86, 14);
		frmYoneticiIslemleri.getContentPane().add(lblKargoId_1_1);
		
		txtDurum = new JTextField();
		txtDurum.setFont(new Font("Arial", Font.PLAIN, 10));
		txtDurum.setColumns(10);
		txtDurum.setBounds(106, 226, 86, 20);
		frmYoneticiIslemleri.getContentPane().add(txtDurum);
		
		JLabel lblKargoId_1_2 = new JLabel("Durum");
		lblKargoId_1_2.setFont(new Font("Arial", Font.PLAIN, 10));
		lblKargoId_1_2.setBounds(106, 204, 46, 14);
		frmYoneticiIslemleri.getContentPane().add(lblKargoId_1_2);
		
		JButton btnKargoGuncelle_1 = new JButton("Kargo Bilgisi");
		btnKargoGuncelle_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(kargolist.getSelectedIndex()>=0) {
					if(Kargo.kargoBul(Integer.parseInt(String.valueOf(kargolist.getSelectedValue())))!=null) {
						JOptionPane.showMessageDialog(null, Kargo.kargoBul(Integer.parseInt(String.valueOf(kargolist.getSelectedValue()))).toString());	
					}
					else {
						JOptionPane.showMessageDialog(null, "Bu Numaraya Ait bir kargo bulunamadi, silmis olabilirsiniz.");
					}
				}
			}
		});
		btnKargoGuncelle_1.setFont(new Font("Arial", Font.BOLD, 13));
		btnKargoGuncelle_1.setBounds(212, 215, 123, 31);
		frmYoneticiIslemleri.getContentPane().add(btnKargoGuncelle_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 119, 86, 127);
		frmYoneticiIslemleri.getContentPane().add(scrollPane);
		
		JLabel lblKargolar = new JLabel("Kargolar");
		lblKargolar.setHorizontalAlignment(SwingConstants.CENTER);
		scrollPane.setColumnHeaderView(lblKargolar);
		kargolist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		
		scrollPane.setViewportView(kargolist);
		
		JLabel lblMusteriAd = new JLabel("Musteri Ad");
		lblMusteriAd.setFont(new Font("Arial", Font.PLAIN, 10));
		lblMusteriAd.setBounds(106, 266, 106, 14);
		frmYoneticiIslemleri.getContentPane().add(lblMusteriAd);
		
		txtMusteriAd = new JTextField();
		txtMusteriAd.setFont(new Font("Arial", Font.PLAIN, 10));
		txtMusteriAd.setColumns(10);
		txtMusteriAd.setBounds(106, 289, 106, 20);
		frmYoneticiIslemleri.getContentPane().add(txtMusteriAd);
		
		JLabel lblMusteriSoyad = new JLabel("Musteri Soyad");
		lblMusteriSoyad.setFont(new Font("Arial", Font.PLAIN, 10));
		lblMusteriSoyad.setBounds(222, 266, 109, 14);
		frmYoneticiIslemleri.getContentPane().add(lblMusteriSoyad);
		
		txtMusteriSoyad = new JTextField();
		txtMusteriSoyad.setFont(new Font("Arial", Font.PLAIN, 10));
		txtMusteriSoyad.setColumns(10);
		txtMusteriSoyad.setBounds(222, 289, 109, 20);
		frmYoneticiIslemleri.getContentPane().add(txtMusteriSoyad);
		
		txtMusteriSifre = new JTextField();
		txtMusteriSifre.setFont(new Font("Arial", Font.PLAIN, 10));
		txtMusteriSifre.setColumns(10);
		txtMusteriSifre.setBounds(339, 289, 128, 20);
		frmYoneticiIslemleri.getContentPane().add(txtMusteriSifre);
		
		JLabel lblMusteriSifre = new JLabel("Musteri Sifre");
		lblMusteriSifre.setFont(new Font("Arial", Font.PLAIN, 10));
		lblMusteriSifre.setBounds(339, 266, 128, 14);
		frmYoneticiIslemleri.getContentPane().add(lblMusteriSifre);
		
		JButton btnMusteriEkle = new JButton("Musteri Ekle");
		btnMusteriEkle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!txtMusteriAd.getText().isEmpty()&&!txtMusteriSoyad.getText().isEmpty()&&!txtMusteriSifre.getText().isEmpty()) {
					Musteri yeni =new Musteri(txtMusteriAd.getText(),txtMusteriSoyad.getText(),txtMusteriSoyad.getText());
					MusteriModel.addElement(String.valueOf(yeni.getMusteriid()));
				}
				else {
					JOptionPane.showMessageDialog(null,"Gerekli Alanlari Doldurunuz");
				}
			}
		});
		btnMusteriEkle.setFont(new Font("Arial", Font.BOLD, 13));
		btnMusteriEkle.setBounds(256, 331, 227, 31);
		frmYoneticiIslemleri.getContentPane().add(btnMusteriEkle);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 266, 86, 151);
		frmYoneticiIslemleri.getContentPane().add(scrollPane_1);
		
		JLabel lblMusteriId = new JLabel("Musteri ID");
		lblMusteriId.setHorizontalAlignment(SwingConstants.CENTER);
		scrollPane_1.setColumnHeaderView(lblMusteriId);
		
		
		scrollPane_1.setViewportView(musterilist);
		
		JButton btnMusteriGuncelle = new JButton("Musteri Guncelle");
		btnMusteriGuncelle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(musterilist.getSelectedIndex()>=0) {
					Musteri guncelle = Musteri.musteriBul(Integer.valueOf(musterilist.getSelectedValue().toString()));
					if(guncelle!=null) {
						if(!txtMusteriAd.getText().isEmpty()) {
							guncelle.setAd(txtMusteriAd.getText());
						}
						if(!txtMusteriSoyad.getText().isEmpty()) {
							guncelle.setSoyad(txtMusteriSoyad.getText());
						}
						if(!txtMusteriSifre.getText().isEmpty()) {
							guncelle.setSifre(txtMusteriSifre.getText());
						}
						JOptionPane.showMessageDialog(null, "Girilen veriler guncellendi!");
					}
				}
			}
		});
		btnMusteriGuncelle.setFont(new Font("Arial", Font.BOLD, 13));
		btnMusteriGuncelle.setBounds(256, 368, 227, 31);
		frmYoneticiIslemleri.getContentPane().add(btnMusteriGuncelle);
		
		JButton btnMusteriSil = new JButton("Sil");
		btnMusteriSil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(musterilist.getSelectedIndex()>=0) {
					Musteri sil = Musteri.musteriBul(Integer.valueOf(musterilist.getSelectedValue().toString()));
					if(sil!=null) {
						Musteri.Musteriler.remove(sil);
						JOptionPane.showMessageDialog(null, "Musteri Kaydi Silindi!");
					}
				}
			}
		});
		btnMusteriSil.setFont(new Font("Arial", Font.BOLD, 13));
		btnMusteriSil.setBounds(106, 368, 140, 32);
		frmYoneticiIslemleri.getContentPane().add(btnMusteriSil);
		
		JButton btnHakkinda = new JButton("Hakkinda");
		btnHakkinda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(musterilist.getSelectedIndex()>=0) {
					Musteri bilgi = Musteri.musteriBul(Integer.valueOf(musterilist.getSelectedValue().toString()));
					if(bilgi!=null) {
						JOptionPane.showMessageDialog(null, bilgi.toString());
					}
				}
			}
		});
		btnHakkinda.setFont(new Font("Arial", Font.BOLD, 13));
		btnHakkinda.setBounds(106, 330, 140, 32);
		frmYoneticiIslemleri.getContentPane().add(btnHakkinda);
	}
}
