import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Anasayfa {

	private JFrame anasayfa;
	private JTextField yoneticiSifre;
	private JTextField txtMusteriSifre;
	private JTextField txtMusteriid;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DosyaOku();
					Anasayfa window = new Anasayfa();
					window.anasayfa.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		Runtime.getRuntime().addShutdownHook(new Thread()
		{
		    @Override
		    public void run()
		    {
		       DosyaYaz();
		    }
		});
	}

	public Anasayfa() {
		initialize();
	}
	public static void DosyaOku() {
		int sayac=0;
		try {
		      File dosya = new File("kargo.txt");
		      Scanner sc = new Scanner(dosya);
		      while (sc.hasNextLine()) {
		        String data = sc.nextLine();
		        String[] veriler = data.split(",");
		        sayac++;
		        new Kargo(Integer.parseInt(veriler[0]),Integer.parseInt(veriler[1]),Integer.parseInt(veriler[2]),veriler[3],veriler[4],Double.parseDouble(veriler[5]),veriler[6]);
		      }
		      sc.close();
		      Kargo.uniqueid=sayac;
		      sayac=0;
		      dosya = new File("kisiler.txt");
		      sc = new Scanner(dosya);
		      while (sc.hasNextLine()) {
		        String data = sc.nextLine();
		        String[] veriler = data.split(",");
		        sayac++;
		        new Musteri(Integer.parseInt(veriler[0]),veriler[1],veriler[2],veriler[3]);
		      }
		      sc.close();
		      Musteri.uniqueid=sayac;
		      Kargo.uniqueid=sayac;
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
	}
	public static void DosyaYaz() {
		try {
		      FileWriter kargoyaz = new FileWriter("kargo.txt");
		      for(Kargo kargo:Kargo.Kargolar) {
		    	  kargoyaz.write(kargo.getKargoid()+","+kargo.getGonderenid()+","+kargo.getGonderilenid()+","+kargo.getGonderenAdres()+","+kargo.getGonderilenAdres()+","+kargo.getKargoUcreti()+","+kargo.getDurum()+"\n");
		      }
		      kargoyaz.close();
		      FileWriter kisiyaz = new FileWriter("kisiler.txt");
		      for(Musteri musteri:Musteri.Musteriler) {
		    	  kisiyaz.write(musteri.getMusteriid()+","+musteri.getAd()+","+musteri.getSoyad()+","+musteri.getSifre()+"\n");
		      }
		      kisiyaz.close();
		      System.out.println("Veriler basari ile kaydedildi..");
		    } catch (IOException e) {
		      System.out.println("Dosya yazarken bir hata olustu.");
		      e.printStackTrace();
		    }
	}
	private void initialize() {
		anasayfa = new JFrame();
		anasayfa.setTitle("Kargo Anasayfa");
		anasayfa.setBounds(100, 100, 450, 272);
		anasayfa.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		anasayfa.getContentPane().setLayout(null);
		
		JButton cikis = new JButton("Cikis");
		cikis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		cikis.setFont(new Font("Tahoma", Font.PLAIN, 13));
		cikis.setBounds(123, 170, 174, 51);
		anasayfa.getContentPane().add(cikis);
		
		JLabel lblNewLabel = new JLabel("Yonetici Girisi");
		lblNewLabel.setBounds(10, 26, 147, 14);
		anasayfa.getContentPane().add(lblNewLabel);
		
		yoneticiSifre = new JTextField();
		yoneticiSifre.setBounds(52, 70, 105, 20);
		anasayfa.getContentPane().add(yoneticiSifre);
		yoneticiSifre.setColumns(10);
		
		JButton btnNewButton = new JButton("Yonetici Girisi");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(!yoneticiSifre.getText().isEmpty()) {
						if(yoneticiSifre.getText().equals("admin")) {
							YoneticiEkrani window = new YoneticiEkrani();
							window.frmYoneticiIslemleri.setVisible(true);
						}
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(10, 101, 147, 29);
		anasayfa.getContentPane().add(btnNewButton);
		
		JLabel lblSifre = new JLabel("Sifre");
		lblSifre.setBounds(10, 73, 32, 14);
		anasayfa.getContentPane().add(lblSifre);
		
		JLabel lblSifre_1 = new JLabel("Sifre");
		lblSifre_1.setBounds(277, 73, 32, 14);
		anasayfa.getContentPane().add(lblSifre_1);
		
		txtMusteriSifre = new JTextField();
		txtMusteriSifre.setColumns(10);
		txtMusteriSifre.setBounds(319, 70, 105, 20);
		anasayfa.getContentPane().add(txtMusteriSifre);
		
		JButton btnMusteriGirisi = new JButton("Musteri Girisi");
		btnMusteriGirisi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!txtMusteriSifre.getText().isEmpty()&&!txtMusteriid.getText().isEmpty()) {
					Musteri m = Musteri.musteriBul(Integer.parseInt(txtMusteriid.getText()));
					if(m!=null) {
						if(m.getSifre().equals(txtMusteriSifre.getText())) {
							MusteriSayfasi window = new MusteriSayfasi(Integer.parseInt(txtMusteriid.getText()));
							window.frmMusteriBilgilendirme.setVisible(true);
						}
						else {
							JOptionPane.showMessageDialog(null, "Hatali sifre.");
						}
					}
					else {
						JOptionPane.showMessageDialog(null, "Bu ID'ye ait bir musteri bulunamadi.");
					}
				}
			}
		});
		btnMusteriGirisi.setBounds(277, 101, 147, 29);
		anasayfa.getContentPane().add(btnMusteriGirisi);
		
		JLabel lblMusteriGirisi = new JLabel("Musteri Girisi");
		lblMusteriGirisi.setBounds(276, 26, 148, 14);
		anasayfa.getContentPane().add(lblMusteriGirisi);
		
		JLabel lblSifre_1_1 = new JLabel("ID");
		lblSifre_1_1.setBounds(277, 45, 32, 14);
		anasayfa.getContentPane().add(lblSifre_1_1);
		
		txtMusteriid = new JTextField();
		txtMusteriid.setColumns(10);
		txtMusteriid.setBounds(319, 42, 105, 20);
		anasayfa.getContentPane().add(txtMusteriid);
	}
}
