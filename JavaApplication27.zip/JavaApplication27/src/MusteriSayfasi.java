import java.awt.EventQueue;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import java.awt.Color;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;

public class MusteriSayfasi {

	JFrame frmMusteriBilgilendirme;
	private JList list;
	JLabel lblkargoid;
	JLabel lblgonderenid;
	JLabel idlabel;
	JLabel lblaliciid;
	JLabel lblgonderenadres;
	JLabel lblgonderilenadres;
	JLabel lblucret;
	JLabel lbldurum;
	DefaultListModel<String> KargoModel = new DefaultListModel<String>();
	Musteri aktif;
	
	public MusteriSayfasi(int id) {
		aktif=Musteri.musteriBul(id);
		initialize();
		idlabel.setText(String.valueOf(aktif.getMusteriid()));
		kargoListele();
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MusteriSayfasi window = new MusteriSayfasi();
					window.frmMusteriBilgilendirme.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public MusteriSayfasi() {
		initialize();
		idlabel.setText(String.valueOf(aktif.getMusteriid()));
		kargoListele();
	}

	
	void kargoListele() {
		for(Kargo kargo:Kargo.Kargolar) {
			if(kargo.getGonderenid()==aktif.getMusteriid()||kargo.getGonderilenid()==aktif.getMusteriid()) {
				KargoModel.addElement(String.valueOf(kargo.getKargoid()));
			}
		}
	}
	
	private void initialize() {
		frmMusteriBilgilendirme = new JFrame();
		frmMusteriBilgilendirme.setTitle("Musteri Bilgilendirme");
		frmMusteriBilgilendirme.setBounds(100, 100, 435, 407);
		frmMusteriBilgilendirme.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		frmMusteriBilgilendirme.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 35, 120, 315);
		frmMusteriBilgilendirme.getContentPane().add(scrollPane);
		 list = new JList(KargoModel);
		 list.addListSelectionListener(new ListSelectionListener() {
		 	public void valueChanged(ListSelectionEvent arg0) {
		 		Kargo kargo = Kargo.kargoBul(Integer.parseInt(String.valueOf(list.getSelectedValue())));
		 		if(kargo!=null) {
		 			lblkargoid.setText(String.valueOf(kargo.getKargoid()));
		 			lblgonderenid.setText(String.valueOf(kargo.getGonderenid()));
		 			lblaliciid.setText(String.valueOf(kargo.getGonderilenid()));
		 			lblucret.setText(String.valueOf(kargo.getKargoUcreti())+"TL");
		 			lbldurum.setText(String.valueOf(kargo.getDurum()));
		 			lblgonderenadres.setText(kargo.getGonderenAdres());
		 			lblgonderilenadres.setText(kargo.getGonderilenAdres());
		 		}
		 	}
		 });
		 list.setVisibleRowCount(0);
		 list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		scrollPane.setViewportView(list);
		
		JLabel lblNewLabel = new JLabel("Kargolariniz");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		scrollPane.setColumnHeaderView(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ID'niz: ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(10, 11, 54, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblNewLabel_1);
		
		 idlabel = new JLabel("0");
		idlabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		idlabel.setHorizontalAlignment(SwingConstants.CENTER);
		idlabel.setBounds(74, 11, 46, 14);
		frmMusteriBilgilendirme.getContentPane().add(idlabel);
		
		JLabel lblNewLabel_2 = new JLabel("Kargo Numarasi");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(140, 11, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblNewLabel_2);
		
		lblkargoid = new JLabel("");
		lblkargoid.setHorizontalAlignment(SwingConstants.CENTER);
		lblkargoid.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblkargoid.setBounds(140, 36, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblkargoid);
		
		JLabel lblNewLabel_2_1 = new JLabel("Gonderen ID");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_1.setBounds(140, 61, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblNewLabel_2_1);
		
		lblgonderenid = new JLabel("");
		lblgonderenid.setHorizontalAlignment(SwingConstants.CENTER);
		lblgonderenid.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblgonderenid.setBounds(140, 86, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblgonderenid);
		
		JLabel lblNewLabel_2_2 = new JLabel("Alici ID");
		lblNewLabel_2_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_2.setBounds(140, 111, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblNewLabel_2_2);
		
		 lblaliciid = new JLabel("");
		lblaliciid.setHorizontalAlignment(SwingConstants.CENTER);
		lblaliciid.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblaliciid.setBounds(140, 136, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblaliciid);
		
		JLabel lbl_ = new JLabel("Gonderenin Adresi");
		lbl_.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_.setFont(new Font("Tahoma", Font.BOLD, 15));
		lbl_.setBounds(140, 161, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lbl_);
		
		 lblgonderenadres = new JLabel("");
		lblgonderenadres.setHorizontalAlignment(SwingConstants.CENTER);
		lblgonderenadres.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblgonderenadres.setBounds(140, 186, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblgonderenadres);
		
		JLabel lblNewLabel_2_4 = new JLabel("Gonderilen Adres");
		lblNewLabel_2_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_4.setBounds(140, 211, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblNewLabel_2_4);
		
		 lblgonderilenadres = new JLabel("");
		lblgonderilenadres.setHorizontalAlignment(SwingConstants.CENTER);
		lblgonderilenadres.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblgonderilenadres.setBounds(140, 236, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblgonderilenadres);
		
		JLabel lblNewLabel_2_4_1 = new JLabel("Kargo Ucreti");
		lblNewLabel_2_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_4_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_4_1.setBounds(140, 261, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblNewLabel_2_4_1);
		
		 lblucret = new JLabel("");
		lblucret.setHorizontalAlignment(SwingConstants.CENTER);
		lblucret.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblucret.setBounds(140, 286, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblucret);
		
		JLabel lblNewLabel_2_4_2 = new JLabel("Kargo Durumu");
		lblNewLabel_2_4_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_4_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_4_2.setBounds(140, 311, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lblNewLabel_2_4_2);
		
		 lbldurum = new JLabel("");
		lbldurum.setHorizontalAlignment(SwingConstants.CENTER);
		lbldurum.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lbldurum.setBounds(140, 336, 246, 14);
		frmMusteriBilgilendirme.getContentPane().add(lbldurum);
	}

}
